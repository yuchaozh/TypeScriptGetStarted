In order to run the Multimath demo application, you must have Node.js and npm installed.

The demo code does not include the npm packages required to run the application. You can install those packages by running the following command from inside the multimath folder:

npm install