"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Player = (function () {
    function Player() {
    }
    Player.prototype.formatName = function () {
        return this.name.toUpperCase();
    };
    return Player;
}());
exports.Player = Player;
//# sourceMappingURL=player.js.map